import pandas as pd

# Load data
df = pd.read_csv('../data/raw_data.csv')
print(df.head())