# Sales & Revenue Forecasting Project

This project aims to forecast sales and revenue using Python, Power BI, SQL, and R.